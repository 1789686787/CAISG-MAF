import numpy as np


arr = np.zeros((3,4))

print(arr[0][1])